
 
									#####################################################################################################################################
									# Script Name: NS.Project.py                                                                                                        #
									# Description: Domain mapper is a structured approach to network security of the organization.                                      #
									#              This project is aimed at taking proactive measures to enhance the organization defense system, as well as            #
									#              empowering cybersecurity teams. The goal of the network security project is to effectively map the domains           #
									#              active directory objects as well as existing networks. The domain mapper emphasizes the importance of                #
									#              detecting vulnerabilities and possible exploitation methods. The project is divided into three main sections:        #
									#              Scanning, Enumeration, and Exploitation, while each is critical to the comprehensive analysis of network             #
									#              vulnerabilities.                                                                                                     #
									#                                                                                                                                   #
									# Author: Adir Salinas (code S18)                                                                                                   #
									# Date: 24.05.2024                                                                                                                  #
									# Class code: 7736                                                                                                                  #
									# Lecturer: Natali Erez                                                                                                             #
									#####################################################################################################################################


import os							# This imports the os module, which provides functions for interacting with the operating system, such as executing system commands.
import subprocess					# This imports the subprocess module, which allows you to spawn new processes, connect to their input/output/error pipes, and obtain their return codes.
import ipaddress					# This imports the ipaddress module, which provides the capabilities to create, manipulate, and operate on IPv4 and IPv6 addresses and networks.
import time							# The time module provides various time-related functions. In this script, it is used to introduce delays (pauses) in the execution to simulate a waiting period, which can improve the user experience by giving visual feedback.
import shutil						# This command imports the shutil module, which provides a higher-level interface for file operations such as copying and removing files and directories.
import gzip							# This command imports the gzip module, which provides functionalities to read and write GNU zip files (.gz), enabling compression and decompression of files.
import sys							# The import sys command imports the sys module, which provides access to system-specific parameters and functions, such as handling command-line arguments and interacting with the Python interpreter.
import tty							# The import tty command imports the tty module, which provides functions for changing the terminal mode, such as setting the terminal to raw mode, where input is not processed (e.g., no line buffering).
import termios						# The import termios command imports the termios module, which provides an interface for configuring and controlling terminal I/O settings on Unix-like systems, allowing detailed control over terminal behavior, such as modifying input and output modes.
import pyfiglet						# The import pyfiglet command imports the pyfiglet module, which allows for the creation of large ASCII art text banners from standard text strings, enhancing the visual presentation of text in terminal applications.
from termcolor import colored		# This command imports the colored function from the termcolor module, which allows for printing colored text in the terminal.
from colorama import init, Style	# This command imports the init function and the Style class from the colorama module. The init function initializes colorama to enable colored terminal text on Windows, and the Style class provides various text styling options such as bright, dim, and reset.

os.system('clear')												# This command clears the terminal screen on Unix-like systems (Linux).
print("\n[!] Before We Start, Please Insert Your Password:\n")	# Prints a message prompting the user to insert their password, with line breaks before and after the message for better readability.
os.system('sleep 2')											# Pauses the script execution for 2 seconds using the system's sleep command.
os.system('sudo -kv')											# Runs the sudo -kv command to validate and cache the user's password for a period, ensuring that subsequent sudo commands do not prompt for a password immediately.
os.system('clear')												# This command clears the terminal screen on Unix-like systems (Linux).			
current_directory = os.getcwd()									# Gets the current working directory and assigns it to the variable current_directory.

def get_key():																	# This function reads a single key press from the user without displaying it on the screen.
    fd = sys.stdin.fileno()														# Gets the file descriptor for standard input (stdin).
    old_settings = termios.tcgetattr(fd)										# Saves the current terminal settings so they can be restored later.
    try:																		# Begins a block of code to try setting the terminal to raw mode.
        tty.setraw(sys.stdin.fileno())											# Sets the terminal to raw mode, where input is read character by character without echoing.
        sys.stdin.read(1)														# Reads a single character from stdin.
    finally:																	# Ensures that the following code runs even if an error occurs.
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)					# Restores the terminal to its original settings.

def display_welcome_message():													# This function displays a welcome message in the terminal with styled text and pauses between steps.
	os.system('clear')															# Clears the terminal screen.
	banner = pyfiglet.figlet_format("Domain Mapper")							# Creates a large ASCII art banner with the text "Domain Mapper" using pyfiglet.
	colored_banner = colored(banner, color='cyan', attrs=['bold'])				# Colors the banner cyan and makes it bold.
	print(colored_banner)														# Prints the colored banner to the terminal.
	time.sleep(2.5)																# Pauses for 2.5 seconds to allow the user to read the banner.

	main_description = "	Welcome to the Domain Mapper Script!"				# Defines the main description text.
	task_description = "\n	This script will perform the following tasks:\n"	# Defines the task description text.
	print(colored(main_description, color='red', attrs=['bold']))				# Colors the main description text red and makes it bold, then prints it.
	time.sleep(2)																# Pauses for 2 seconds to allow the user to read the main description.
	print(colored(task_description, color='yellow', attrs=['bold']))			# Colors the task description text yellow and makes it bold, then prints it.

	# Creates a list called options containing strings that describe the tasks the script will perform. Each string is indented for better readability.
	options = [
		"     1. Scanning the network to identify active hosts and open ports.",
		"     2. Enumerating network services and extracting detailed information.",
		"     3. Exploiting identified vulnerabilities to test security defenses.",
		"     4. Generating a comprehensive PDF report with all findings and analyses.\n"
	]

	for option in options:														# Iterates through each string in the options list.
		time.sleep(2)															# Pauses for 2 seconds using time.sleep(2).
		print(colored(option, color='yellow', attrs=['bold']))					# Prints each option in bold yellow using the colored function from the termcolor module to make the text visually distinct and easier to read.
	time.sleep(2)																# Adds a final 2-second pause after printing all the options, allowing the user time to read the last option before proceeding.
	 
	main_final = "	Please ensure you have the necessary permissions to run these operations."			# Assigns the string " Please ensure you have the necessary permissions to run these operations." to the variable main_final. This message informs the user that they need the necessary permissions to execute the script properly.
	second_final = "\n	The process will start shortly... Sit back and let the script do its work!"		# Assigns the string "\n The process will start shortly... Sit back and let the script do its work!" to the variable second_final. This message informs the user that the script will begin soon and they can relax while the script runs.
	print(colored(main_final, color='magenta', attrs=['bold']))											# Prints the main_final message to the terminal in bold magenta text. This makes the message stand out to ensure the user reads it.
	time.sleep(2)																						# Pauses the script for 2 seconds to allow the user to read the main_final message before continuing.
	print(colored(second_final, color='magenta', attrs=['bold']))										# Prints the second_final message to the terminal in bold magenta text. This provides the user with information about the script starting shortly.
	time.sleep(5)																						# Pauses the script for 5 seconds to give the user ample time to read the second_final message before proceeding.

	print(colored("\n\n	Press any key to continue...", attrs=['bold']))									# Prints the message "\n\n Press any key to continue..." in bold text. This prompt tells the user to press any key to continue, indicating a break point in the script.
	get_key()																							# Calls the get_key() function, which waits for the user to press any key without displaying the key press on the screen. This ensures the script only continues after user confirmation.
display_welcome_message()																				# Calls the display_welcome_message() function to display the welcome message and instructions when the script starts.

os.system('echo "\nProject Title: Domain Mapper.\n" >> PDF')	# Appends the text "Project Title: Domain Mapper." with line breaks before and after, to a file named PDF using the system's echo command.
os.system('echo "Start Time: $(date)" >> PDF')					# Appends the text "Start Time:" followed by the current date and time to the file named PDF using the system's echo and date commands.

def IP_check(network_range):										# Defines a function named IP_check that takes one argument, network_range.					
	try:															# Starts a try block to catch any potential exceptions that might occur during the execution of the code within this block.
		if '-' in network_range:									# Checks if the network_range contains a hyphen, indicating an IP range (e.g., 192.168.1.1-192.168.1.10).
			ip_start, ip_end = network_range.split('-')				# Splits the range into starting and ending IP addresses.
			ipaddress.ip_address(ip_start)							# Validates the starting IP address
			if '.' not in ip_end:									# Checks if the ending part of the range is just the last octet.
				ip_end = ip_start.rsplit('.', 1)[0] + '.' + ip_end	# Constructs the full IP address by combining the first three octets of ip_start with the last octet from ip_end.
			ipaddress.ip_address(ip_end)							# Validates the constructed ending IP address.
		else:														# If there is no hyphen, assume the input is a network with a subnet mask (e.g., 192.168.1.0/24).
			ip, subnet_mask = network_range.split('/')				# Splits the input into an IP address and a subnet mask.
			ipaddress.ip_network(network_range, strict=False)		# Validates the network address with the subnet mask.
		return True													# If no exceptions were raised, the input is valid, and the function returns True.
	except ValueError:												# Catches any ValueError exceptions that were raised during validation.
		return False												# If an exception was caught, the input is invalid, and the function returns False.									

def IP_Range():																			# Defines a function named IP_Range with no arguments.
	while True:																			# Starts an infinite loop, which will continue until it encounters a break statement.
		Network_Range = input("\n\n[»] Please Enter a Network Range to Scan: ")			# Prompts the user to enter a network range and stores the input in the variable Network_Range.
		if not IP_check (Network_Range):												# Calls the IP_check function with Network_Range as an argument. If IP_check returns False (indicating an invalid range), the code inside the if block is executed.
			print("\n[!] The Provided Network Range Is Invalid! Please try again...\n")	# Prints an error message indicating that the provided network range is invalid.
			os.system('sleep 3')														# Pauses execution for 3 seconds.	
			os.system('clear')															# Clears the console.
		else:																			# If IP_check returns True (indicating a valid range), the code inside the else block is executed.
			print("\n[✓] Network range verified successfully.")							# Prints a message confirming that the provided network range is valid.
			os.system('sleep 3')														# Pauses execution for 3 seconds.			
			break																		# The break statement terminates the loop. If a valid network range is provided, the loop will exit, and the program will continue with the code after the loop.
	return Network_Range																# Returns the validated network range.
provided_range = IP_Range()																# Calls the IP_Range function and stores the returned network range in the variable provided_range.


def Domain_Cred():																			# Defines a function named Domain_Cred that collects the domain name and Active Directory (AD) credentials from the user.
	print("\n\n[!] Please provide the Domain name and Active Directory (AD) credentials: ")	# Prints a message prompting the user to provide the domain name and AD credentials, with line breaks for readability.
	os.system('sleep 2')																	# Pauses the script execution for 2 seconds using the system's sleep command.
	domain_name = input("\n[»] Please Provide the Domain Name: ")							# Prompts the user to enter the domain name and assigns the input to the variable domain_name.
	ad_username = input("\n[»] Please Provide the AD Username: ")							# Prompts the user to enter the AD username and assigns the input to the variable ad_username.
	ad_password = input("\n[»] Please Provide the AD Password: ")							# Prompts the user to enter the AD password and assigns the input to the variable ad_password.
	print("\n[✓] Thank you! The provided information has been recorded.")					# Prints a message confirming that the provided information has been recorded, with line breaks for readability.
	os.system('sleep 3')																	# Pauses the script execution for 3 seconds using the system's sleep command.
	return domain_name, ad_username, ad_password											# Returns the collected domain name, AD username, and AD password.
Domain_Name, AD_Username, AD_Password = Domain_Cred()										# Calls the Domain_Cred function and assigns its returned values to the variables Domain_Name, AD_Username, and AD_Password.

os.makedirs("DataResualt", exist_ok=True)				# Creates a directory named DataResualt if it does not already exist. The exist_ok=True argument prevents an error from being raised if the directory already exists.
os.chdir("DataResualt")									# Changes the current working directory to DataResualt, allowing subsequent file operations to take place within this directory.


def AutoFiles():																							# This line defines a function named AutoFiles. This function is intended to automate the process of handling files, specifically related to the RockYou password list.
    # Path to rockyou.txt.gz
    rockyou_gz_path = "/usr/share/wordlists/rockyou.txt.gz"  												# This line assigns the file path of the compressed RockYou password list (rockyou.txt.gz) to the variable rockyou_gz_path.									

    # Check if rockyou.txt.gz exists
    if not os.path.exists(rockyou_gz_path):																	# This conditional statement checks if the file rockyou.txt.gz exists at the specified path. os.path.exists() is a function from the Python os module that returns True if the file or directory exists; otherwise, it returns False.
        print("\n[!] Error: rockyou.txt.gz not found at /usr/share/wordlists/. Please make sure it exists.")# If the rockyou.txt.gz file is not found, this line prints an error message indicating that the file was not found at the specified location.
        return False																						# After printing the error message, the function returns False, indicating that the operation failed. However, there seems to be a small issue here. It calls LoginChoice(), a function which isn't defined in the code snippet. It should probably raise an error or handle the flow differently.
        LoginChoice()

    try:																	#  This line starts a try block. The code inside this block is monitored for exceptions. If an exception occurs during the execution of the code within the try block, it will be caught by the except block (if one is provided).
        # Copy rockyou.txt.gz to current directory
        shutil.copy(rockyou_gz_path, os.getcwd())							# This line copies the rockyou.txt.gz file from its original location (rockyou_gz_path) to the current working directory (os.getcwd()). The shutil.copy() function from the shutil module is used for file copying.

        # Extract rockyou.txt.gz to current directory
        with gzip.open(os.path.basename(rockyou_gz_path), 'rb') as f_in: 	# This line opens the rockyou.txt.gz file in binary read mode ('rb') using the gzip.open() function from the gzip module. os.path.basename() extracts the filename from the full path.
            with open('pass.lst', 'wb') as f_out:							# This line opens a new file named pass.lst in binary write mode ('wb'). This file will contain the extracted passwords from rockyou.txt.gz.
                shutil.copyfileobj(f_in, f_out)								# This line copies the contents of the rockyou.txt.gz file (opened as f_in) to the newly created pass.lst file (opened as f_out).

        # Remove rockyou.txt from directory
        os.remove(os.path.basename(rockyou_gz_path))						# This line removes the rockyou.txt.gz file from the current directory after it has been copied and extracted. os.remove() is used to delete files.
        os.remove("rockyou.txt")											# This line removes a file named rockyou.txt from the directory. It seems to be an error because rockyou.txt is never mentioned before. It should probably be removed or renamed.

        return True															# Finally, if all the operations are successful, the function returns True, indicating that the operation completed without errors.
    except Exception as e:													# This line catches any exceptions that might occur during the execution of the try block and assigns them to the variable e.
        return False														# If an exception occurs, the function returns False, indicating that the operation failed.


def UserFiles():																									# This line defines a function named UserFiles.
    while True:																										# This initiates an infinite loop. The code inside this loop will keep running until a break statement is encountered.
        os.system('clear')																							# This command clears the terminal screen.
        file_pass_path = input("\n[»] Please Enter a Path to a File That Contains Passwords That You Wish to Use: ")# This line prompts the user to input a path to a file containing passwords. The input is stored in the variable file_pass_path.


        if os.path.isfile(file_pass_path):										# This condition checks if the input provided by the user (file_pass_path) corresponds to a valid file path using os.path.isfile(). If the path is valid, it continues with the next steps.
            time.sleep(2)														# This line introduces a 2-second delay in the execution of the program, making it pause for a short while.
            print("\n[✓] File exists and is valid to use. Progressing... \n")	# If the file exists and is valid, this message is printed, indicating that the program is progressing.
            shutil.copy(file_pass_path, "pass.lst")								# This line copies the file specified by the user (file_pass_path) to a file named pass.lst.
            time.sleep(2)														# This line introduces a 2-second delay in the execution of the program, making it pause for a short while.
            break																# This statement exits the loop, ending the repetitive process.
        else:																	# If the condition (if os.path.isfile(file_pass_path):) is not met, meaning the file path provided by the user is invalid, this part of the code is executed.
            print("\n[!] File not found. Please try again... \n")				# This message is printed to notify the user that the file was not found, prompting them to try again.
            time.sleep(2)														# This line introduces a 2-second delay in the execution of the program, making it pause for a short while.
    print("\n[√] Thank you! Your data input has been successfully recorded!\n")	# After a valid file path is provided and the file is copied, this message is printed to acknowledge successful data input.
    time.sleep(2)																# This line introduces a 2-second delay in the execution of the program, making it pause for a short while.
    os.system('clear')															# This command clears the terminal screen before exiting the function.


def UserWordsLog():																				# This line defines a function named UserWordsLog.
    os.system('clear')																			# This command clears the terminal screen.
    print("\n[»] Please Enter The Passwords You Wish to Use:")									# This line prompts the user to enter passwords.
    time.sleep(1)																				# This introduces a 1-second delay.
    print("\n[!] Make sure to press 'Enter' after each Password. (Press CTRL+D when finished)")	# This line instructs the user to press 'Enter' after each password and to press CTRL+D when they finish entering passwords.
    time.sleep(1)																				# Another 1-second delay is introduced.
    print("\nYour Chosen Passwords:\n")															# This line prints a header indicating that the entered passwords will be displayed.
    with open("pass.lst", "w") as f:															# This line opens a file named pass.lst in write mode ("w"). The file will store the passwords entered by the user. The with statement ensures that the file is properly closed after writing.
        while True:																				# This initiates an infinite loop.
            try:																				# This starts a try block to handle exceptions.
                password = input()																# This line prompts the user to input a password. The input is stored in the variable password.
                f.write(password + "\n")														# This writes the entered password followed by a newline character ("\n") to the pass.lst file.
            except EOFError:																	# If the user presses CTRL+D (EOF - End of File), it raises an EOFError exception, which is caught here.
                break            																# This statement breaks out of the loop when the user finishes entering passwords.
    print("\n[√] Thank you! Your data input has been successfully recorded!\n")					# After the user finishes entering passwords, this message confirms that the data input has been successfully recorded.
    time.sleep(2)																				# A 2-second delay is introduced.


def LoginChoice():							# This line defines a function named LoginChoice().
    while True:								# This initiates an infinite loop, allowing the user to make multiple choices until a valid one is entered.
        os.system('clear')					# This command clears the terminal screen.
        
        # The following lines print out a menu for the user to choose from different options to provide a password list for a brute force attack. The options are:
        print("\n[!] Collected inforamtion: ")
        print("\n+-----------------------------------+" )
        print("|--> Network Range: " + provided_range)
        print("|--> Domain Name: " + Domain_Name )
        print("+-----------------------------------+" )
        print("\n[*] To Initiate the Brute Force Attack, a Password List is Essential")
        print("[»] Please Choose How You Wish to Provide the Password List:\n")
        print(" A) Auto - Automatically use the default Rockyou password list to be used in the brute force attack.")
        print(" P) Path - Enter paths to your own file that containing passwords that you wish to use in the brute force.")
        print(" M) Manual - Provides the option to manually input few passwords on the screen for utilization in the brute force attack.\n")
        print("    +--------------------------------------------------------+")		
        print("    |  ..) To Exit The Framework, Simply type '..' or 'Exit' |")
        print("    +--------------------------------------------------------+\n")

        UserChoice = input("    ┌─[Enter Your Choice]\n    └─────► ").strip().lower() 						# This line prompts the user to enter their choice and stores it in the variable UserChoice. The input is converted to lowercase and stripped of leading/trailing whitespaces.

        if UserChoice in ['a', 'auto']:																		# Checks if the user's choice is to use the default Rockyou password list.
            print("            └─────► You Have Chosen to Use the Default Rockyou Password List!")			# This line prints a message indicating that the user has chosen to Use the Default Rockyou Password List.
            time.sleep(2)																					# This command introduces a 2-second delay, allowing the user some time to read the message.
            AutoFiles() 																					# If the user chooses to use the default Rockyou password list, this function is called to handle the process.
            break																							# This statement breaks out of the loop, ending the repetitive process.
        elif UserChoice in ['p', 'path']:																	# Checks if the user's choice is to provide a path to a custom password list.
            print("            └─────► You Have Chosen the Option to Enter a Path to Your Password List!")	# This line prints a message indicating that the user has chosen to enter a path to their own password list.
            time.sleep(2)																					# This command introduces a 2-second delay, allowing the user some time to read the message.
            UserFiles() 																					# If the user chooses to enter a path to a custom password list, this function is called to handle the process.
            break																							# This statement breaks out of the loop, ending the repetitive process.
        elif UserChoice in ['m', 'manual']:																	# Checks if the user's choice is to manually input passwords.
            print("            └─────► You Have Chosen the Manual Option to Manually Input Passwords!")		# This line prints a message indicating that the user has chosen to manually input passwords.
            time.sleep(2)																					# This command introduces a 2-second delay, allowing the user some time to read the message.
            UserWordsLog()  																				# If the user chooses the manual option, this function is called to handle the process of manually inputting passwords.
            break																							# This statement breaks out of the loop, ending the repetitive process.
        elif UserChoice in ['..', 'exit']:																	# Checks if the user's choice is to exit the framework.
            print("            └─────► Exiting the framework...")											# This line prints a message indicating that the framework is being exited.
            time.sleep(2)																					# This command introduces a 2-second delay, allowing the user some time to read the message.
            exit()																							# This function exits the program.
        else:																								# If the user's input doesn't match any of the previous conditions, this block of code executes.
            print("            └─────► Invalid choice! Please try again...")								# This line prints a message indicating that the user has made an invalid choice.
            time.sleep(3)																					# This command introduces a 3-second delay, allowing the user some time to read the message.
LoginChoice()
																		

def Scanning():																# Defines a function named Scanning that performs the network scanning operation.
	os.chdir(current_directory)												# Changes the current working directory back to the original directory stored in the variable current_directory.
	subprocess.run(['python', 'Scanning.py', provided_range, Domain_Name])	# Runs the Scanning.py script using the subprocess.run function, passing the provided_range and Domain_Name as arguments to the script. This executes the scanning process with the specified parameters.
Scanning()																	# Calls the Scanning function to initiate the scanning process.

def Enumeration():																						# Defines a function named Enumeration that performs the network enumeration operation.
	os.chdir(current_directory)																			# Changes the current working directory back to the original directory stored in the variable current_directory.
	subprocess.run(['python', 'Enumeration.py', provided_range, Domain_Name, AD_Username, AD_Password])	# Runs the Enumeration.py script using the subprocess.run function, passing the provided_range, Domain_Name, AD_Username, and AD_Password as arguments to the script. This executes the enumeration process with the specified parameters.
Enumeration()																							# Calls the Enumeration function to initiate the enumeration process.
 
def Exploitation():																						# Defines a function named Exploitation that performs the network exploitation operation.
	os.chdir(current_directory)																			# Changes the current working directory back to the original directory stored in the variable current_directory.
	subprocess.run(['python', 'Exploitation.py', provided_range, Domain_Name, AD_Username, AD_Password])# Runs the Exploitation.py script using the subprocess.run function, passing the provided_range, Domain_Name, AD_Username, and AD_Password as arguments to the script. This executes the exploitation process with the specified parameters. 	
Exploitation()																							# Calls the Exploitation function to initiate the exploitation process.

def PDF_File(): # Defines a function named PDF_File that handles the creation of a PDF report summary and displays messages to the user.
	
	os.chdir(current_directory)																																# Changes the current working directory back to the original directory stored in the variable current_directory.
	os.system('clear')																																	 	# Clears the terminal screen using the system's clear command.
	text = "\n\n\n\n                                                          After completing the entire process, a PDF report will be generated."			# Creates a string variable text with a message about generating a PDF report.
	colored_text = colored(text, color='yellow', attrs=['bold'])																							# Colors the text string in yellow and makes it bold using the colored function from the termcolor module.
	print(colored_text)																																		# Prints the colored and bold text message to the terminal.
	os.system('sleep 3')																																	# Pauses the script execution for 3 seconds using the system's sleep command.
	text = "\n\n                                               The PDF report will summarize the investigation, providing detailed findings and analysis..."# Creates another string variable text with a message about the contents of the PDF report.
	colored_text = colored(text, color='red', attrs=['bold'])																								# Colors the text string in red and makes it bold using the colored function from the termcolor module.
	print(colored_text)																																		# Prints the colored and bold text message to the terminal.
	
	# These commands append various pieces of information, including end time, author details, project explanation, and project structure, to a file named PDF:
	os.system('echo "End Time: $(date)" >> PDF')
	os.system('echo "\nAuthor: Adir Salinas" >> PDF')
	os.system('echo "Linkedin: www.linkedin.com/in/adirsalinas" >> PDF')
	os.system('echo "Github: https://github.com/AdirSalinas" >> PDF')
	os.system('echo "\n\nProject Explanation:" >> PDF')
	os.system('''echo "Domain mapper is a structured approach to network security of the organization. \nThis project is aimed at taking proactive measures to enhance the organization defense \nsystem, as well as empowering cybersecurity teams. \nThe goal of the network security project is to effectively map the domains active \ndirectory objects as well as existing networks. \nThe domain mapper emphasizes the importance of detecting vulnerabilities and possible \nexploitation methods. \nThe project is divided into three main sections: Scanning, Enumeration, and Exploitation. \nwhile each is critical to the comprehensive analysis of network vulnerabilities." >> PDF''')
	os.system('echo "\n\nProject Structure:" >> PDF')
	os.system('echo "[*] The project will be divided into three phases: Scanning, Enumeration and Exploitation." >> PDF')
	os.system('echo "\n -> Scanning Mode:" >> PDF')
	os.system('echo "            Basic: Use the -Pn option in Nmap to assume all hosts are online, bypassing the                   discovery phase. \n\n     Intermediate: Scan all 65535 ports using the -p- flag. \n\n         Advanced: Include UDP scanning for a thorough analysis." >> PDF')
	os.system('echo "\n -> Enumeration Mode:\n               Basic: \n                   1) Identify services (-sV) running on open ports.\n                   2) Identify the IP Address of the Domain Controller.\n                   3) Identify the IP Address of the DHCP server.\n\n        Intermediate: \n                   1) Enumerate IPs for key services: FTP, SSH, SMB, WinRM, LDAP, RDP.\n                   3) Add three (3) NSE scripts you think can be relevant for enumerating \n                      domain networks." >> PDF')
	os.system('echo "\n            Advanced: \n                   1) Extract all users. \n                   2) Extract all groups. \n                   3) Extract all shares. \n                   4) Display password policy. \n                   5) Find disabled accounts. \n                   6) Display accounts that are members of the Domain Admins group." >> PDF')
	os.system('echo "\n -> Exploitation Mode:\n                Basic: Deploy the NSE vulnerability scanning script.\n\n         Intermediate: Execute domain-wide password spraying to identify weak credentials.\n\n             Advanced: Extract and attempt to crack Kerberos tickets using pre-supplied \n                       passwords.	" >> PDF')
	os.system('echo "\n\n\n\n\n                  The Entire Results are Presented On The Next Page!" >> PDF 2>/dev/null')
	os.system('''echo "\n\n\n\n  The entire data and results of the project are located inside the directory 'DataResult'." >> PDF 2>/dev/null''')	
	os.system('echo "\n\n      [!] The following are the entire results and data that were extracted during the \n                                  scanning process!" >> PDF 2>/dev/null')
	os.system(f'echo "\n\n -> The network range you chose to scan is: {provided_range}" >> PDF 2>/dev/null')
	os.system(f'echo "\n[*] The following IP addresses appear to have open ports:\n" >> PDF 2>/dev/null')
	os.system('cat DataResualt/Network_Open_IP >> PDF 2>/dev/null')
	os.system(f'echo "\n\n[*] The following are the results of the scanning process:" >> PDF 2>/dev/null')
	os.system('cat DataResualt/Scanning_Data/Resualt* >> PDF 2>/dev/null')
	os.system('echo "\f\n\n      [!] The following are the entire results and data that were extracted during the \n                                  Enumeration process!" >> PDF 2>/dev/null')
	os.system(f'echo "\n\n[*] The following are the results of the version scanning process:" >> PDF 2>/dev/null')
	os.system('cat DataResualt/Enumeration_Data/"Version Data"/* >> PDF 2>/dev/null')
	os.system('echo "\n" >> PDF')
	os.system('cat DataResualt/Enumeration_Data/"Domain Controller IP Address" >> PDF 2>/dev/null')
	os.system('echo "\n" >> PDF')
	os.system('cat DataResualt/Enumeration_Data/"DHCP Server IP Address" >> PDF 2>/dev/null')
	os.system('echo "\f\n\n" >> PDF')
	os.system('cat DataResualt/Enumeration_Data/"Detected Key Services" >> PDF 2>/dev/null')
	os.system('echo "\n\n" >> PDF')
	os.system('cat DataResualt/Enumeration_Data/"Domain NSE Scripts" >> PDF 2>/dev/null')
	os.system('echo "\f\n\n" >> PDF')
	os.system('cat DataResualt/Enumeration_Data/"Advanced Enumeration"/Extracted* >> PDF 2>/dev/null')
	os.system('echo "\f\n\n" >> PDF')
	os.system('cat DataResualt/Exploitation_Data/"NSE Vuln Resualt" >> PDF 2>/dev/null')
	os.system('echo "\f\n\n" >> PDF')
	os.system('cat DataResualt/Exploitation_Data/"Weak Credentials Resualt" >> PDF 2>/dev/null')
	os.system('cat DataResualt/Exploitation_Data/"Kerberos tickets" >> PDF 2>/dev/null')	
	os.system('echo "\n\n\n                             Thank you for using my project!" >> PDF 2>/dev/null')	
	os.system('echo "\n    If you have any questions or need further assistance, please feel free to contact me." >> PDF 2>/dev/null')
	os.system('echo "\n                                      Adir Salinas" >> PDF 2>/dev/null')	
	os.system('echo "                                Email: adir735@gmail.com" >> PDF 2>/dev/null')	
	os.system('echo "                          LinkedIn: https://github.com/AdirSalinas" >> PDF 2>/dev/null')	
	os.system('echo "                          Github: www.linkedin.com/in/adirsalinas" >> PDF 2>/dev/null')	
	os.system('echo "\n                                Enjoy your investigation." >> PDF 2>/dev/null')
		
	os.system('enscript PDF -p PDF_before > /dev/null 2>&1')																			# Converts the PDF text file to a PostScript file named PDF_before, suppressing any output or errors.
	os.system('ps2pdf PDF_before DataResualt/DomainMapper.pdf > /dev/null 2>&1')														# Converts the PDF_before PostScript file to a PDF file named DomainMapper.pdf in the DataResualt directory, again suppressing any output or errors.
	os.system('rm -rf PDF* >/dev/null 2>&1')																							# Removes the intermediate files (PDF and PDF_before) to clean up, suppressing any output or errors.

	os.system('sleep 5')																												# Pauses the script execution for 5 seconds.	
	text = "\n\n\n                                                                       The PDF file has been created successfully!"	# Prepares a message indicating the successful creation of the PDF file.
	colored_text = colored(text, color='green', attrs=['bold'])																			# Colors the message text in green and makes it bold using the colored function from the termcolor module.
	print(colored_text)																													# Prints the colored and bold text message to the terminal.
	os.system('sleep 3')																												# Pauses the script execution for 3 seconds.
PDF_File()																																# Calls the PDF_File function to execute the PDF generation and cleanup process.

def Removing_Temp_Files():								# Defines a function named Removing_Temp_Files that handles the cleanup of temporary files generated during the script's execution.
	os.chdir("DataResualt")								# Changes the current working directory to DataResualt, where the temporary files are located.
	os.system('rm -rf Network_Open_IP 2>/dev/null')		# Removes the file or directory named Network_Open_IP, suppressing any error messages by redirecting them to /dev/null.
	os.system('rm -rf Network_Range 2>/dev/null')		# Removes the file or directory named Network_Range, suppressing any error messages by redirecting them to /dev/null.
	os.system('rm -rf pass.lst 2>/dev/null')			# Removes the file named pass.lst, suppressing any error messages by redirecting them to /dev/null.
Removing_Temp_Files()									# Calls the Removing_Temp_Files function to initiate the cleanup process.

def end_animation():
    os.system('clear')																							# Clears the terminal screen to provide a clean space for displaying the banner and messages.

    result = subprocess.run(['figlet', '-t', 'All Tasks Completed!'], capture_output=True, text=True)			# Uses the subprocess module to run the figlet command with the -t flag and the text "All Tasks Completed!". This command generates an ASCII art representation of the text. capture_output=True captures the output of the command. text=True ensures the output is returned as a string.
    banner = result.stdout																						# Stores the standard output (stdout) of the figlet command, which contains the ASCII art representation of the text.
    colored_banner = colored(banner, color='cyan', attrs=['bold'])												# Uses the colored function from the termcolor module to color the ASCII art banner in cyan and make it bold.

    end_message = "    The Domain Mapper Script has completed successfully."									# Defines a string variable end_message with the text "The Domain Mapper Script has completed successfully." The text is indented for formatting purposes.
    final_message = "\n    Thanks you for using my project, have a great day and enjoy your investigation!"		# Defines a string variable final_message with the text "Thanks you for using my project, have a great day and enjoy your investigation!". The text includes a newline character at the beginning for spacing and is indented for formatting purposes.
    data_message = "\n    All data has been saved and stored in the directory named 'DataResualt'."				# Defines a string variable data_message with the text "All data has been saved and stored in the directory named 'DataResualt'.". The text includes a newline character at the beginning for spacing and is indented for formatting purposes.
    
    print(colored_banner)																						# Prints the colored ASCII art banner to the terminal.
    time.sleep(1)																								# Pauses the script execution for 1 second to allow the user to view the banner before the next messages are displayed.

    for char in end_message:																					# Initiates a loop to iterate over each character in the end_message string.
        print(colored(char, color='green', attrs=['bold']), end='', flush=True)									# Prints each character in end_message one by one. Prints each character in end_message one by one. end='': Ensures that the print function does not move to a new line after printing each character. end='': Ensures that the print function does not move to a new line after printing each character.
        time.sleep(0.05)																						# Pauses the execution for 0.05 seconds between printing each character to create an animation effect.
    print()																										# Moves to a new line after the entire end_message is printed.									
    time.sleep(1)																								# Pauses the execution for 1 second before printing the next message.
	
    for char in final_message:																					# Initiates a loop to iterate over each character in the final_message string.
        print(colored(char, color='yellow', attrs=['bold']), end='', flush=True)								# Prints each character in final_message one by one. colored(char, color='yellow', attrs=['bold']): Colors each character yellow and makes it bold. end='': Ensures that the print function does not move to a new line after printing each character. flush=True: Forces the print output to be flushed to the terminal immediately.
        time.sleep(0.05)																						# Pauses the execution for 0.05 seconds between printing each character to create an animation effect.
    print()																										# Moves to a new line after the entire final_message is printed.
    time.sleep(1)																								# Pauses the execution for 1 second before printing the next message.					

    for char in data_message:																					# Initiates a loop to iterate over each character in the data_message string.
        print(colored(char, attrs=['bold']), end='', flush=True)												# Prints each character in data_message one by one. colored(char, attrs=['bold']): Makes each character bold. end='': Ensures that the print function does not move to a new line after printing each character. flush=True: Forces the print output to be flushed to the terminal immediately.
        time.sleep(0.05)																						# Pauses the execution for 0.05 seconds between printing each character to create an animation effect.
    print()																										# Moves to a new line after the entire data_message is printed.
    time.sleep(4)																								# Pauses the execution for 4 seconds to allow the user to read the final message before ending the script.				
end_animation()																									# Calls the end_animation function to execute the entire end animation process.
