

									#####################################################################################################################################
									# Script Name: Scanning.py                                                                                                       	#
									# Description: Domain mapper is a structured approach to network security of the organization.                                      #
									#              This project is aimed at taking proactive measures to enhance the organization defense system, as well as            #
									#              empowering cybersecurity teams. The goal of the network security project is to effectively map the domains           #
									#              active directory objects as well as existing networks. The domain mapper emphasizes the importance of                #
									#              detecting vulnerabilities and possible exploitation methods. The project is divided into three main sections:        #
									#              Scanning, Enumeration, and Exploitation, while each is critical to the comprehensive analysis of network             #
									#              vulnerabilities.                                                                                                     #
									#                                                                                                                                   #
									# Author: Adir Salinas (code S18)                                                                                                   #
									# Date: 24.05.2024                                                                                                                  #
									# Class code: 7736                                                                                                                  #
									# Lecturer: Natali Erez                                                                                                             #
									#####################################################################################################################################


import os							# This imports the os module, which provides functions for interacting with the operating system, such as executing system commands.
import subprocess					# This imports the subprocess module, which allows you to spawn new processes, connect to their input/output/error pipes, and obtain their return codes.
import ipaddress					# This imports the ipaddress module, which provides the capabilities to create, manipulate, and operate on IPv4 and IPv6 addresses and networks.
import time							# The time module provides various time-related functions. In this script, it is used to introduce delays (pauses) in the execution to simulate a waiting period, which can improve the user experience by giving visual feedback.
import sys							# This command imports the sys module in Python, which provides access to some variables used or maintained by the Python interpreter and to functions that interact strongly with the interpreter.
from termcolor import colored		# This command imports the colored function from the termcolor module, which allows for printing colored text in the terminal.
from colorama import init, Style	# This command imports the init function and the Style class from the colorama module. The init function initializes colorama to enable colored terminal text on Windows, and the Style class provides various text styling options such as bright, dim, and reset.

provided_range = sys.argv[1]		# This command assign the first command-line argument passed to the script to the variable provided_range.
Domain_Name = sys.argv[2]			# This command assign the second command-line argument passed to the script to the variable Domain_Name.
os.chdir("DataResualt")				# This command changes the current working directory of the script to the "DataResualt" directory.

def Basic_Scan(provided_range):		# The Basic_Scan function performs a network scan to identify active hosts and open ports within a provided network range.
	os.makedirs("Scanning_Data", exist_ok=True)					# Ensures the directory Scanning_Data exists for storing scan data.
	os.system('clear')											# Clears the terminal screen for clarity.
	text = "\n »» Scanning Process...\n"						# Displays the start of the scanning process with a highlighted and bold text for visibility.
	colored_text = colored(text, color='cyan', attrs=['bold'])
	print(colored_text)
	os.system('sleep 2')										# Pauses the script for 2 seconds to allow the user to read the process initiation message.
	print("\n[?] Scanning Process: Identifying Active Hosts and Open Ports...\n")											# Informs the user that the script is identifying active hosts and open ports.
	os.system('sleep 2')																									# Pauses the script for 2 seconds to allow the user to read the process initiation message.
	print("\n[!] Please wait while we scan your network range...\n")														# Advises the user to wait as the scanning of the network range begins, followed by another 2-second pause for readability.	
	os.system(f'nmap {provided_range} -sL | awk \'{{print $(NF)}}\' | grep ^[0-9] > Network_Range')							# Runs an nmap command to list all IPs in the provided network range, filtering and storing the results in a file named Network_Range.
	os.system(f'sudo nmap {provided_range} -Pn --open |grep -i "report for" | awk \'{{print $(NF)}}\' > Network_Open_IP')	# Executes a more detailed nmap scan to detect hosts with open ports, storing the output in Network_Open_IP.
	print("\n[*] The following IP addresses appear to have open ports:\n")													# Displays the IP addresses that have open ports by reading from the Network_Open_IP file.
	time.sleep(2)																											# Pauses the script for 2 seconds after displaying the IP addresses, giving the user time to view the results.
	os.system('cat Network_Open_IP')																						# Outputs the contents of the file Network_Open_IP to the console, showing the user which IP addresses were found to have open ports
	time.sleep(2)																											# Pauses the script for 2 seconds after displaying the IP addresses, giving the user time to view the results.
	with open("Network_Open_IP", "r") as file:																				# Opens the Network_Open_IP file in read mode, reads its contents, splits the content into lines (removing any newline characters), and stores the list of IP addresses in the variable ip_addresses for further use.
		ip_addresses = file.read().splitlines()	
				
	for ip in ip_addresses:																							# Iterates over each IP address stored in the ip_addresses list, executing the subsequent commands for each IP.
		print(f"\n\n -> Scanning {ip}...")																			# Prints a message indicating the start of a scanning process for the current IP address, giving a clear, user-friendly notification of which IP is being scanned.
		time.sleep(1)																								# Pauses the script for 1 second to ensure that the scanning message is visible to the user, helping to space out the actions for readability.
		os.system(f'\n echo " \n-> The following resualt scan are for: {ip} \n" >> "Scanning_Data/Resualt {ip}"')	# Appends a header message to a file specific to the current IP, indicating that the results following this message are for the scanned IP. This message provides context within the result file.
		os.system(f'sudo nmap {ip} -Pn --open >> "Scanning_Data/Resualt {ip}"')										# Executes an nmap scan on the current IP to find open ports, appending the output to a file named after the IP address in the Scanning_Data directory. This ensures that all open port information is captured and stored for review.
		print(f"\n\n[✓] Nmap Scan for {ip} Completed. Output Saved Successfully...")								# After the scan completes, prints a success message indicating that the nmap scan for the current IP has finished and the results have been successfully saved. This feedback is essential for user assurance and script progress tracking.
		time.sleep(2)																								# Pauses the script for 2 seconds after scanning each IP, providing a brief interval before the next actions start, which aids in maintaining a clear, understandable output flow.
	text = "\n\n[+] The Entire Scanning Process Completed Successfully."											# After all IPs have been processed, sets a message indicating that the entire scanning process has successfully completed.
	colored_text = colored(text, color='green', attrs=['bold'])														# Formats the completion message in bold and green color using the termcolor module, making the success message stand out in the terminal output.
	print(colored_text)																								# Displays the formatted completion message, visually signaling to the user that the entire set of scanning tasks has been executed without any issues.
	time.sleep(4)																									# Concludes the function with a 4-second pause, giving users ample time to read the final message before the script possibly terminates or moves on to further tasks.

def Intermediate_Scan(provided_range): 																						# Defines a function to perform a more detailed network scan that not only identifies active hosts but also checks more comprehensively for open ports.
	os.makedirs("Scanning_Data", exist_ok=True)																				# Ensures that the directory Scanning_Data exists where scan results will be stored, or creates it if it doesn't exist, without throwing an error if the directory is already present.
	os.system('clear')																										# Clears the console to provide a clean slate for new output, enhancing readability for the user.
	text = "\n »» Scanning Process...\n"																					# Sets up an initial message that signals the beginning of the scanning process.
	colored_text = colored(text, color='cyan', attrs=['bold'])																# Enhances the visibility of the starting message by applying cyan color and bold formatting, making it stand out in the terminal.
	print(colored_text)																										# Displays the formatted starting message to the user, clearly indicating the start of the scanning process.
	os.system('sleep 2')																									# Introduces a short pause (2 seconds) to allow the user time to read the initial scanning message before proceeding.
	print("\n[?] Scanning Process: Identifying Active Hosts and Open Ports...\n")											# Notifies the user about the specific actions being undertaken by the scan—identifying active hosts and open ports—which provides clarity on what the scan is focused on at this stage.
	os.system('sleep 2')																									# Adds another 2-second pause to ensure the user has time to absorb the information provided by the process description.
	print("\n[!] Please wait while we scan your network range...\n")														# Sets expectations for the user to wait as the scanning takes place, indicating that the process may take some time.
	os.system(f'nmap {provided_range} -sL | awk \'{{print $(NF)}}\' | grep ^[0-9] > Network_Range')							# Executes an initial nmap command that lists all hosts within the provided network range, using awk to extract and grep to filter IP addresses, storing them in a file named Network_Range. This step maps out the network for further detailed scanning.
	os.system(f'sudo nmap {provided_range} -Pn --open |grep -i "report for" | awk \'{{print $(NF)}}\' > Network_Open_IP')	# Runs a more intensive nmap scan with the -Pn option to treat all hosts as online, aiming to discover open ports, and saves the output showing IPs with open ports to a file named Network_Open_IP.
	print("\n[*] The following IP addresses appear to have open ports:\n")													# Informs the user of the results, specifically which IP addresses from the scan have open ports, preparing them to view the specific details.
	time.sleep(2)																											# Delays the continuation of the script by 2 seconds, providing a natural break for the user to get ready to see the listed IP addresses.
	os.system('cat Network_Open_IP')																						# Outputs the contents of the Network_Open_IP file to the terminal, allowing the user to see which IP addresses were found to have open ports during the scan.
	time.sleep(2)																											# Implements another brief pause post-displaying the results, which helps in not overwhelming the user with immediate continuation of other operations.
	with open("Network_Open_IP", "r") as file:																				# Opens the file containing the IP addresses with open ports for further processing.
		ip_addresses = file.read().splitlines()																				# Reads the IP addresses from the file and splits them into a list by line, which is useful for further individual processing of each IP address in subsequent steps of the scan or other related processes.
		
	for ip in ip_addresses:																									# Iterates over each IP address in the ip_addresses list. Each IP address is processed in the sequence defined inside the loop.
		print(f"\n\n -> Scanning {ip}...")																					# Displays a message indicating the start of the scanning process for each specific IP address. This provides real-time feedback to the user on the progress of the scan.
		time.sleep(1)																										# Pauses the execution for 1 second after displaying the scanning message. This brief pause helps ensure that the scanning messages are not rushed and gives the user time to read them.
		os.system(f'\n echo " \n-> The following resualt scan are for: {ip} \n" >> "Scanning_Data/Resualt {ip}"')			# Appends a header message to a file specific for each IP address, indicating the scanning results that follow pertain to that IP. This message helps organize the output data within the file.
		os.system(f'sudo nmap {ip} -p- -T4 -Pn --open >> "Scanning_Data/Resualt {ip}"')										# Runs an nmap scan on each IP with sudo privileges, scanning all 65535 ports (-p-), using a faster timing template (-T4), treating hosts as online (-Pn), and looking specifically for open ports. The results are appended to the respective result file for each IP address.
		print(f"\n\n[✓] Nmap Scan for {ip} Completed. Output Saved Successfully...")										# Notifies the user that the nmap scan for the current IP address has finished and that the output has been successfully saved to the file. This feedback is important for user assurance and for tracking the progress of the scan.
		time.sleep(2)																										# Adds a 2-second pause after each scan completion, allowing users to notice the completion message before moving on to the next IP address.
	text = "\n\n[+] The Entire Scanning Process Completed Successfully."													# After all IP addresses have been processed, sets a message indicating the successful completion of the entire scanning process.
	colored_text = colored(text, color='green', attrs=['bold'])																# Applies formatting to the completion message, making it bold and green to emphasize success and make it stand out in the terminal output.
	print(colored_text)																										# Displays the formatted completion message, clearly signaling to the user that the entire set of scanning tasks has been executed without issues.
	time.sleep(4)																											# Ends the function with a 4-second pause, ensuring the user has ample time to view the completion message before the script potentially exits or moves on to additional tasks.
	
def Advanced_Scan(provided_range):																							# The Advanced_Scan function defined here is designed to perform a comprehensive network scan, following a structured process to identify active hosts and open ports within a specified network range. Here’s a detailed breakdown of each step within this function:														
	os.makedirs("Scanning_Data", exist_ok=True)																				# Ensures the existence of a directory named Scanning_Data where the scan results will be stored. If the directory already exists, no error is thrown due to the exist_ok=True parameter.
	os.system('clear')																										# Clears the console to ensure that the output from previous commands does not clutter the screen, providing a clean visual start for the new scan results.
	text = "\n »» Scanning Process...\n"																					# Prepares a message indicating the beginning of the scanning process.
	colored_text = colored(text, color='cyan', attrs=['bold'])																# Applies formatting to the initial message, using cyan color and bold attributes to make it visually prominent, enhancing readability and attention.
	print(colored_text)																										# Outputs the formatted scanning initiation message to the console, signaling the start of the process clearly to the user.
	os.system('sleep 2')																									# Pauses the execution of the script for 2 seconds after displaying the initiation message, providing a brief interval for the user to read and process the information.
	print("\n[?] Scanning Process: Identifying Active Hosts and Open Ports...\n")											# Informs the user specifically what the scan will be focusing on: identifying active hosts and open ports, which are crucial for network security assessments.
	os.system('sleep 2')																									# Introduces another pause for 2 seconds to allow the user time to read and understand the scope of the scan before it proceeds.
	print("\n[!] Please wait while we scan your network range...\n")														# Requests the user's patience as the scanning process gets underway, indicating that it might take some time due to the depth and thoroughness of the scan.
	os.system(f'nmap {provided_range} -sL | awk \'{{print $(NF)}}\' | grep ^[0-9] > Network_Range')							# Executes a command using nmap to list all hosts in the specified range, processes the output to extract and list IP addresses, and saves these to the file Network_Range.
	os.system(f'sudo nmap {provided_range} -Pn --open |grep -i "report for" | awk \'{{print $(NF)}}\' > Network_Open_IP')	# Runs an nmap scan with elevated privileges to find all open ports on the identified hosts in the provided range, refining the output to capture relevant data, and storing it in Network_Open_IP.
	print("\n[*] The following IP addresses appear to have open ports:\n")													# Displays a message summarizing that the scanned IP addresses with open ports will be listed next, preparing the user for viewing the detailed results.
	time.sleep(2)																											# Pauses the script for another 2 seconds post-message, ensuring the user has sufficient time to ready themselves for the detailed data.
	os.system('cat Network_Open_IP')																						# Uses the cat command to display the contents of Network_Open_IP, which contains details of the IPs with open ports.
	time.sleep(2)																											# Adds another brief pause to allow the user to review the displayed IP addresses without rushing to the next script section.
	with open("Network_Open_IP", "r") as file:																				# Opens the file Network_Open_IP for reading.
		ip_addresses = file.read().splitlines()																				# Reads the entire content of the file, splits it into lines, and stores these in the list ip_addresses. This list will be used for further detailed scanning or reporting.
		
	for ip in ip_addresses:																									# Iterates through each IP address provided in the ip_addresses list, executing the subsequent steps for each individual IP.
		print(f"\n\n -> Scanning {ip}...")																					# Outputs a message to the console indicating the commencement of the scan for the current IP address, providing clear real-time feedback on the scanning progress.
		time.sleep(1)																										# Introduces a brief pause (1 second) after the scanning message to allow the user to acknowledge which IP is being scanned before the detailed process begins.
		os.system(f'\n echo " \n-> The following resualt scan are for: {ip} \n" >> "Scanning_Data/Resualt {ip}"')			# Appends a header to a file dedicated to this IP address (Scanning_Data/Result {ip}), which helps in distinguishing the scanning results for different IP addresses within the file system.
		os.system(f'sudo nmap {ip} -p- -sU -T4 -Pn --open -n --max-retries 1 >> "Scanning_Data/Resualt {ip}"')				# Conducts a thorough nmap scan on the current IP address using several options:-p-: Scans all 65535 ports.-sU: Performs a UDP scan.-T4: Uses aggressive timing, speeding up the scan.-Pn: Skips host discovery, treating all hosts as online. --open: Shows only open ports. -n: Skips DNS resolution to speed up the scan. --max-retries 1: Limits the number of retries for each port to 1. This command line directs nmap to perform a detailed and aggressive scan, saving the output to the dedicated file for comprehensive review.
		print(f"\n\n[✓] Nmap Scan for {ip} Completed. Output Saved Successfully...")										# Notifies the user upon the successful completion of the scan for the specific IP address and confirms that the results have been saved to the file.
		time.sleep(2)																										# Adds a 2-second pause after the completion of the scan for each IP, providing a clear break between the output of different IP addresses, enhancing readability.
	text = "\n\n[+] The Entire Scanning Process Completed Successfully."													# Prepares a message to be displayed at the end of all scans, indicating that the entire scanning operation has been successfully completed.
	colored_text = colored(text, color='green', attrs=['bold'])																# Formats the completion message in bold green text, making it visually distinct and signaling success in a visually appealing manner.
	print(colored_text)																										# Displays the formatted success message, clearly communicating to the user that all planned scanning activities have been executed without any issues.
	time.sleep(4)																											# Concludes the function with a final 4-second pause, allowing the user sufficient time to absorb the completion message before the script ends or transitions to other operations.			

def Scanning_Menu():							
    while True:																							# This initiates an infinite loop, which will continue running until explicitly interrupted by a break statement or other interrupt. It's commonly used in scripts to create a persistent state or repeat actions until a specific condition is met.															
        os.system('clear')																				# Clears the console to ensure that the output from previous commands does not clutter the screen, providing a clean visual start for the new scan results.							
        
        # The following lines print out a menu for the user to choose from different options to Select the Desired Operation Level for Scanning Mode.					
        print("\n[!] Collected inforamtion: ")
        print("\n+-----------------------------------+" )
        print("|--> Network Range: " + provided_range)
        print("|--> Domain Name: " + Domain_Name )
        print("+-----------------------------------+" )        
        print("\n[*] To initiate the scanning process, you will need to specify the desired depth of the scan:")
        print("[»] Please Select the Desired Operation Level for Scanning Mode:\n")
        print(" 1) Basic - Perform a basic scan assuming all hosts are online, bypassing the host discovery phase and directly scanning the target hosts.")
        print(" 2) Intermediate - Conduct a thorough scan of all 65535 ports on the target hosts, providing a comprehensive view of the target's open ports.")
        print(" 3) Advanced - Execute a comprehensive scan including both TCP and UDP scanning, This option may take longer but offers more detailed scanning data.\n")
        print("    +--------------------------------------------------------+")		
        print("    |  ..) To Exit The Framework, Simply type '..' or 'Exit' |")
        print("    +--------------------------------------------------------+\n")

        UserChoice = input("    ┌─[Enter Your Choice]\n    └─────► ").strip().lower() 					# This line prompts the user to enter their choice and stores it in the variable UserChoice. The input is converted to lowercase and stripped of leading/trailing whitespaces.	

        if UserChoice in ['1', 'basic']:																# This line checks if the user's input corresponds to either "1" or "basic". It's designed to capture the user's intent to select the Basic Scanning Mode, whether they enter the number associated with the option or the textual description. This makes the user interface more intuitive and flexible.																	 
            print("            └─────► You Have Selected Basic Scanning Mode!")							# This command outputs a message to the terminal confirming that the user has selected the Basic Scanning Mode. The message provides clear feedback about the chosen operation, ensuring the user understands their current selection.	
            time.sleep(2)																				# Pauses the script for 2 seconds. This delay allows the user sufficient time to read and process the confirmation message before the function proceeds to execute the scan. Delays like this improve the user experience by preventing the immediate rolling of text on the screen, which can be disorienting.							
            Basic_Scan(provided_range)																	# Calls the Basic_Scan function with the argument provided_range, which is expected to be a string specifying the network range to scan. This function performs the actual network scanning based on the parameters set for a basic scan, which might involve checking for active hosts and open ports with assumed defaults to speed up the process.				
            scanning_mode = "Basic"																		# Sets the variable scanning_mode to the string "Basic". This assignment typically serves to track the type of scan that was executed, which could be useful for conditional operations later in the program or for confirming the operation mode to the user.					
            return scanning_mode																		# This statement immediately returns the value of scanning_mode from the function. Returning from within this conditional branch ends the execution of the Scanning_Menu function and passes the string "Basic" back to the caller. This can be used to adjust program behavior based on the selected scanning mode.																			
            break																						# This break statement is intended to exit the while loop. However, it is effectively unreachable because the return statement above it will always exit the function first. Thus, this break could be considered redundant and can be removed without affecting the program's functionality.		 
        elif UserChoice in ['2', 'intermediate']:														# Checks if the user's input matches "2" or "intermediate".	 
            print("            └─────► You Have Selected Intermediate Scanning Mode!")					# Displays a message confirming that the user has chosen the Intermediate Scanning Mode, providing clear feedback.	
            time.sleep(2)																				# Delays the execution for 2 seconds to allow the user time to read the confirmation message.																
            Intermediate_Scan(provided_range)															# Calls the Intermediate_Scan function, passing the provided_range as an argument. This function is designed to conduct a thorough scan, checking all 65535 ports to provide a comprehensive view of the network's security state.		
            scanning_mode = "Intermediate"																# Assigns the value "Intermediate" to the variable scanning_mode to track the type of scan executed.	
            return scanning_mode																		# Returns the scanning_mode variable, ending the function execution and providing this information back to the caller.																													
            break																						# Exits the loop. As in the previous explanation, this is technically redundant after a return statement.	
        elif UserChoice in ['3', 'advanced']:															# Checks if the input is "3" or "advanced".
            print("            └─────► You Have Selected Advanced Scanning Mode!")						# Outputs a message confirming the selection of the Advanced Scanning Mode.	
            time.sleep(2)																				# Provides a 2-second pause for reading the confirmation message.									
            Advanced_Scan(provided_range)																# Executes the Advanced_Scan function which performs the most comprehensive scan including both TCP and UDP scans. This scan is intended to be the most detailed, potentially uncovering more vulnerabilities.																			
            scanning_mode = "Advanced"																	# Sets scanning_mode to "Advanced".			
            return scanning_mode																		# Ends the function, returning the mode of scanning used.	  																				
            break																						# This break would exit the loop, but again, it's redundant because return exits the function.	
        elif UserChoice in ['..', 'exit']:																# Matches the input to ".." or "exit".	
            print("            └─────► Exiting the framework...")										# Displays an exit message.	
            time.sleep(2)																				# Allows a short pause for the user to acknowledge the exit process.	
            exit()																						# Calls the exit() function to terminate the program.	
        else:																							# Catches any input that does not match the expected commands.	
            print("            └─────► Invalid choice! Please try again...")							# Informs the user that the entered choice is invalid.	
            time.sleep(3)																				# Delays the script for 3 seconds before likely re-displaying the menu, giving the user time to read the message.	
Scanning_Choice = Scanning_Menu()																		# The line Scanning_Choice = Scanning_Menu() calls the Scanning_Menu function, which displays a user menu for selecting a scan type, and assigns the user's choice to the variable Scanning_Choice.
